

public enum EtatArticle {
	EN_COURS_DE_CONTROLE,
	EN_VENTE,

}