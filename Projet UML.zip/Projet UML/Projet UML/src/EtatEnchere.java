public enum EtatEnchere {
    EN_ATTENTE,
    EN_COURS,
    TERMINEE,
    ANNULEE
}
