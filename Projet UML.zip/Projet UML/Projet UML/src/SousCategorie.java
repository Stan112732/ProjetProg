public class SousCategorie {
    public String sousCategorie;

    public SousCategorie (String sousCategorie){
        this.sousCategorie = sousCategorie;
    }
    public String toString(){
        return sousCategorie;
    }
}
