public class Stock {

    public Enchere enchere;
    public int numStock;

    public void calculerPrixMoyen(Enchere modele){
        try {
            ConnectionBD.getPrixMarche(modele);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(modele);

    }

    public void comparerPrix(Enchere enchere){

        try {
            ConnectionBD.acheterAuto(enchere);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    }



